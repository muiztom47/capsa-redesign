import { Link } from 'react-router-dom'

export default function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-line">
      <div
        className="pointer-events-none absolute -top-40 right-[-10%] h-[560px] w-[560px] rounded-full opacity-30 blur-3xl"
        style={{ background: 'radial-gradient(circle, #2B4BF2 0%, transparent 70%)' }}
      />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            'linear-gradient(#F4F6FB 1px, transparent 1px), linear-gradient(90deg, #F4F6FB 1px, transparent 1px)',
          backgroundSize: '56px 56px',
        }}
      />

      <div className="relative mx-auto max-w-7xl px-6 pt-20 pb-24 md:pt-28 md:pb-32 grid grid-cols-1 lg:grid-cols-[1.1fr_0.9fr] gap-16 items-center">
        <div>
          <h1 className="reveal reveal-1 font-serif text-[2.75rem] leading-[1.08] md:text-6xl md:leading-[1.06] tracking-tight max-w-xl">
            One system for how private capital actually gets deployed.
          </h1>
          <p className="reveal reveal-2 mt-7 text-lg text-muted leading-relaxed max-w-md">
            Capsa connects sourcing, underwriting, and portfolio monitoring into a single
            workspace, so investment teams spend their time on judgment, not data entry.
          </p>
          <div className="reveal reveal-3 mt-9 flex flex-wrap items-center gap-4">
            <Link
              to="/contact"
              className="inline-flex items-center rounded-sm bg-accent px-6 py-3.5 text-[15px] font-medium hover:bg-[#3457FF] transition-colors"
            >
              Book a demo
            </Link>
            <Link
              to="/product"
              className="inline-flex items-center px-2 py-3.5 text-[15px] text-paper border-b border-transparent hover:border-paper transition-colors"
            >
              See how it works
            </Link>
          </div>
          <p className="reveal reveal-4 mt-14 text-xs text-muted">
            Built for teams underwriting private credit, growth equity, and infrastructure deals
          </p>
        </div>

        <div className="reveal reveal-2 relative hidden lg:block">
          <div className="rounded-md border border-line bg-panel p-6">
            <div className="flex items-center justify-between border-b border-line pb-4">
              <span className="text-sm text-muted">Portfolio exposure</span>
              <span className="text-sm text-muted">Live</span>
            </div>
            <div className="mt-5 space-y-4">
              {[
                { label: 'Private credit', value: 42 },
                { label: 'Growth equity', value: 31 },
                { label: 'Infrastructure', value: 18 },
                { label: 'Special situations', value: 9 },
              ].map((row) => (
                <div key={row.label}>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="text-paper">{row.label}</span>
                    <span className="text-muted">{row.value}%</span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-line overflow-hidden">
                    <div
                      className="h-full rounded-full bg-accent"
                      style={{ width: `${row.value}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
