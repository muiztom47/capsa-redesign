import { Link } from 'react-router-dom'

export default function CTA() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-24 md:py-28">
      <div className="rounded-md border border-line bg-panel px-8 py-14 md:px-16 md:py-16 flex flex-col md:flex-row md:items-center md:justify-between gap-8">
        <div className="max-w-lg">
          <h2 className="font-serif text-3xl md:text-4xl leading-tight">
            See Capsa on your own pipeline.
          </h2>
          <p className="mt-4 text-muted leading-relaxed">
            Bring a live deal and we'll walk through sourcing, underwriting, and monitoring
            using your own data — no generic demo environment.
          </p>
        </div>
        <Link
          to="/contact"
          className="inline-flex items-center justify-center rounded-sm bg-accent px-7 py-4 text-[15px] font-medium hover:bg-[#3457FF] transition-colors whitespace-nowrap"
        >
          Book a demo
        </Link>
      </div>
    </section>
  )
}
