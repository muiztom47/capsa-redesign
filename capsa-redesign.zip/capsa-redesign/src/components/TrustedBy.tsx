const names = ['Northbridge Capital', 'Arclight Partners', 'Meridian Holdings', 'Vantage Equity', 'Halcyon Group']

export default function TrustedBy() {
  return (
    <section className="border-b border-line">
      <div className="mx-auto max-w-7xl px-6 py-14">
        <p className="text-sm text-muted mb-8">Used by investment teams managing over $40B in committed capital</p>
        <div className="flex flex-wrap items-center gap-x-12 gap-y-6">
          {names.map((name) => (
            <span key={name} className="font-serif text-lg text-muted/80">
              {name}
            </span>
          ))}
        </div>
        <p className="mt-6 text-xs text-muted/70">
          Illustrative logos — replace with your actual client names once you have authorization to display them.
        </p>
      </div>
    </section>
  )
}
