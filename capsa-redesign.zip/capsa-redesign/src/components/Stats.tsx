const stats = [
  { value: '40+', label: 'investment teams underwriting on Capsa' },
  { value: '$40B', label: 'in committed capital tracked' },
  { value: '6 weeks', label: 'average time to full deployment' },
  { value: '99.95%', label: 'platform uptime, SOC 2 Type II' },
]

export default function Stats() {
  return (
    <section className="border-y border-line bg-panel/40">
      <div className="mx-auto max-w-7xl px-6 py-16 grid grid-cols-2 md:grid-cols-4 gap-10">
        {stats.map((s) => (
          <div key={s.label}>
            <p className="font-serif text-3xl md:text-4xl">{s.value}</p>
            <p className="mt-2 text-sm text-muted leading-snug max-w-[18ch]">{s.label}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
