const rows = [
  {
    kicker: 'Sourcing',
    title: 'Every deal in one pipeline, ranked the way your team actually thinks.',
    body: 'Capsa pulls in deal flow from your inbox, data rooms, and existing CRM, then scores each opportunity against the mandates your partners have already agreed on — so nothing gets triaged twice.',
    visual: (
      <div className="rounded-md border border-line bg-panel p-5">
        {['Riverstone Logistics — Series C', 'Amberline Health', 'Cobalt Grid Storage'].map((deal, i) => (
          <div
            key={deal}
            className={`flex items-center justify-between py-3 ${i !== 0 ? 'border-t border-line' : ''}`}
          >
            <span className="text-sm text-paper">{deal}</span>
            <span className="text-xs text-muted rounded-sm border border-line px-2 py-1">
              {i === 0 ? 'Fits mandate' : i === 1 ? 'Reviewing' : 'New'}
            </span>
          </div>
        ))}
      </div>
    ),
  },
  {
    kicker: 'Underwriting',
    title: 'Diligence memos that write themselves from your own data room.',
    body: 'Upload the data room once. Capsa extracts financials, flags covenant risk, and drafts the first pass of your investment memo in your firm\u2019s own template — leaving the judgment calls to your analysts.',
    visual: (
      <div className="rounded-md border border-line bg-panel p-5 font-mono text-xs text-muted leading-relaxed">
        <p className="text-paper mb-2">memo_draft.md</p>
        <p>## Revenue quality</p>
        <p>Net retention 118%, concentrated in top 12 accounts (41%).</p>
        <p className="mt-2">## Covenant risk</p>
        <p>Leverage covenant headroom: 0.6x as of Q2.</p>
      </div>
    ),
  },
  {
    kicker: 'Portfolio monitoring',
    title: 'Know which portfolio company needs attention before the board call does.',
    body: 'Covenant breaches, KPI drift, and reporting gaps surface automatically across every holding, with the underlying source document one click away.',
    visual: (
      <div className="rounded-md border border-line bg-panel p-5 space-y-3">
        <div className="flex items-center justify-between text-sm">
          <span className="text-paper">Cascade Manufacturing</span>
          <span className="text-xs text-accent">Covenant flag</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-paper">Fieldstone Renewables</span>
          <span className="text-xs text-muted">On track</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-paper">Lumen Data Centers</span>
          <span className="text-xs text-muted">On track</span>
        </div>
      </div>
    ),
  },
]

export default function Features() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-24 md:py-32 space-y-24 md:space-y-32">
      {rows.map((row, i) => (
        <div
          key={row.kicker}
          className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
            i % 2 === 1 ? 'lg:[&>*:first-child]:order-2' : ''
          }`}
        >
          <div className="max-w-md">
            <p className="text-sm text-accent mb-3">{row.kicker}</p>
            <h3 className="font-serif text-3xl md:text-[2.2rem] leading-[1.15] mb-5">{row.title}</h3>
            <p className="text-muted leading-relaxed">{row.body}</p>
          </div>
          <div>{row.visual}</div>
        </div>
      ))}
    </section>
  )
}
