import Hero from '../components/Hero'
import TrustedBy from '../components/TrustedBy'
import Features from '../components/Features'
import Stats from '../components/Stats'
import CTA from '../components/CTA'

export default function Home() {
  return (
    <>
      <Hero />
      <TrustedBy />
      <Features />
      <Stats />
      <CTA />
    </>
  )
}
